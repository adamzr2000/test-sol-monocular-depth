# Generated with SOL v0.7.0rc2
import numpy as np
import ctypes
from numpy.ctypeslib import ndpointer, as_ctypes_type
import time

class sol_monocular:
	def create(self, path="."):
		self.lib = ctypes.CDLL(path + "/" + "libsol_monocular.so")
		self.call = self.lib.__getattr__("sol_predict") 
		self.call.restype = None

		self.init = self.lib.__getattr__("sol_monocular_init")
		self.init.restype = None
		self.init.argtypes = None

		self.free = self.lib.__getattr__("sol_monocular_free")
		self.free.restype = None
		self.free.argtypes = None

		self.seed_ = self.lib.__getattr__("sol_monocular_set_seed")
		self.seed_.argtypes = [ctypes.c_uint64]
		self.seed_.restype = None

		self.set_IO_ = self.lib.__getattr__("sol_monocular_set_IO")
		self.set_IO_.restype = None

		self.call_no_args = self.lib.__getattr__("sol_monocular_run")
		self.call_no_args.argtypes = None
		self.call_no_args.restype = None

		self.get_output = self.lib.__getattr__("sol_monocular_get_output")
		self.get_output.argtypes = None
		self.get_output.restype = None

		self.sync = self.lib.__getattr__("sol_monocular_sync")
		self.sync.argtypes = None
		self.sync.restype = None

		self.opt_ = self.lib.__getattr__("sol_monocular_optimize")
		self.opt_.argtypes = [ctypes.c_int]
		self.opt_.restype = None

	def __init__(self, path="."):
		self.create(path)

	def set_seed(self, s):
		arg = ctypes.c_uint64(s)
		self.seed_(arg)

	def optimize(self, level):
		arg = ctypes.c_int(level)
		self.opt_(arg)

	def set_IO(self, args):
		self.set_IO_.argtypes = [ndpointer(as_ctypes_type(x.dtype), flags="C_CONTIGUOUS") for x in args]
		self.set_IO_(*args)

	def run(self, args=None):
		if args:
			self.call.argtypes = [ndpointer(as_ctypes_type(x.dtype), flags="C_CONTIGUOUS") for x in args]
			self.call(*args)
		else:
			self.call_no_args()

	def close(self):
		dlclose_func = ctypes.CDLL(None).dlclose
		dlclose_func.argtypes = (ctypes.c_void_p,)
		dlclose_func.restype = ctypes.c_int
		return dlclose_func(self.lib._handle)


def main():
	# Define Function Parameters (Inputs, Outputs, VDims)---------------------------------------------
	vdims = np.ndarray((1), dtype=np.int64)
	
	input_1_0 = np.random.rand(32, 32, 32, 3, ).astype(np.float32)
	out_0 = np.zeros((32, 16, 16, 1, ), dtype=np.float32)
	dp_args = [input_1_0, out_0, vdims] # Inputs, Outputs, VDims must be in this exact order!

	# Call Function and evaluate output---------------------------------------------
	lib = sol_monocular()
	lib.init() # optional
	lib.set_seed(271828) # optional
	####### Option 1: Run directly #######
	lib.run(dp_args)
	print(f"Max_V: {np.max(out_0, axis=1)}\nMax_I: {np.argmax(out_0, axis=1)}")

	####### Option 2: Run directly #######
	lib.set_IO(dp_args)
	lib.optimize(level=2)
	lib.run() # (async)
	lib.get_output() # syncs
	print(f"Max_V: {np.max(out_0, axis=1)}\nMax_I: {np.argmax(out_0, axis=1)}")
	# Free used data and close lib---------------------------------------------
	e = lib.close()
	lib.free()


if __name__ == "__main__":
	main()
